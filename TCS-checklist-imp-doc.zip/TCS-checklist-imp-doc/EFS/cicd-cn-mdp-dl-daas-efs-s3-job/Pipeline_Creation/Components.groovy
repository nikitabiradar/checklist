//COMMON CONFIGURATION
String CDL_GIT_CREDENTIAL = 'codecommit-credentials' //git
String ENVIRONMENT = 'STAGE'

//TRACK CICD REPO VARIABLES
String TRACK_NAME = 'cn-mdp-dl-daas-efs-s3-job' // Track Name Indicates the Application Name. Example ODP_PGE
String CODECOMMIT_URL = 'https://git-codecommit.cn-northwest-1.amazonaws.com.cn/v1/repos/cicd-cn-mdp-dl-daas-efs-s3-job' //Url of the factory CICD repo

multibranchPipelineJob("$TRACK_NAME-$ENVIRONMENT-CICD-Pipeline") {
    branchSources {
        git {
              id("$TRACK_NAME")
              remote("$CODECOMMIT_URL")
              credentialsId("$CDL_GIT_CREDENTIAL")
              includes('main')
         }   
    }
    displayName("$TRACK_NAME-$ENVIRONMENT-CICD-Pipeline")
    configure { node ->
     def webhookTrigger = node / triggers / 'com.igalg.jenkins.plugins.mswt.trigger.ComputedFolderWebHookTrigger' {
                spec('')
                token("TESTTOKEN")
            }
      }
}